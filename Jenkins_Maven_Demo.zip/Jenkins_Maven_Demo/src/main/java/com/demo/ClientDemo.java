package com.demo;

public class ClientDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Demo d=new Demo();
		System.out.println("multiplication is:-"+d.add(10, 10));
	}

}
