package com.demo;

public class Demo {

	public int add(int x,int y)
	{
		return x*y;
	}
}
